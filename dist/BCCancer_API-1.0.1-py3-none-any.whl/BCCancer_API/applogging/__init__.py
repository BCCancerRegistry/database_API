class RouterLoggingMiddleware:
    pass